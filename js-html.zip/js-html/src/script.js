//function countdown()
//{
  
  //console.log(42)
  //console.log(4)
  //console.log(3)
  //console.log(2)
  //console.log(1)
  
//}
//countdown()

//function sum(){
  //let lap1=40
  //let lap2=50
  //let lap3=10
  //let lap= lap1+lap2+lap3
  //console.log(lap)
//}
//sum()

//let count = 11
  
  
//function lapCompleted(){
   // count = count+1
  
//}
//lapCompleted()

//lapCompleted()

//lapCompleted()
//lapCompleted()
//console.log(count)
